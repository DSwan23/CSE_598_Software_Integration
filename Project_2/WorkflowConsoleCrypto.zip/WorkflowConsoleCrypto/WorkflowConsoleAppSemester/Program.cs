﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web;
using WorkflowConsoleAppSemester.Cryptoservice;
using System.Text;
using System.Threading.Tasks;

namespace WorkflowConsoleAppSemester
{

    class Program
    {
        static void Main(string[] args)
        {
            Activity workflow1 = new Workflow1();
            WorkflowInvoker.Invoke(workflow1);
        }
            
    }
}
